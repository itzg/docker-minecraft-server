mc-image-helper assert fileExists "/data/mods/ExplorersCompass-1.16.5-1.1.2-forge.jar"
mc-image-helper assert fileExists "/data/forge-1.16.5-36.2.34.jar"
