mc-image-helper assert fileExists "/data/pufferfish-*.jar"
