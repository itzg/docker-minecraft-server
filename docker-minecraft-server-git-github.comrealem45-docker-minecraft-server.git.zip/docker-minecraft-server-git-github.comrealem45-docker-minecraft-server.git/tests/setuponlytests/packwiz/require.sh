# maven.packwiz.infra.link is not resolvable
exit 1