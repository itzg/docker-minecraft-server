mc-image-helper assert fileExists "/data/quilt-server-*-launch.jar"
