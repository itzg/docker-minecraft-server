mc-image-helper assert fileExists "/data/world/datapacks/afk*"
mc-image-helper assert fileExists "/data/world/datapacks/graves*"
mc-image-helper assert fileExists "/data/world/datapacks/VanillaTweaks_488158f.zip"
mc-image-helper assert fileExists "/data/resourcepacks/VanillaTweaks_d1d810f.zip"
