mc-image-helper assert fileExists plugins/3836.jar
mc-image-helper assert fileExists plugins/34315.jar
mc-image-helper assert fileExists plugins/6245.jar
mc-image-helper assert fileExists plugins/SkinsRestorer.jar