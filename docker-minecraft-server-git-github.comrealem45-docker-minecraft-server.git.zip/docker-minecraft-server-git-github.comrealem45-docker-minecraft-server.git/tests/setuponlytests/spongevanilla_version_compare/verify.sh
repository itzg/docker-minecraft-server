mc-image-helper assert propertyEquals --file=server.properties --property=difficulty --expect=0
