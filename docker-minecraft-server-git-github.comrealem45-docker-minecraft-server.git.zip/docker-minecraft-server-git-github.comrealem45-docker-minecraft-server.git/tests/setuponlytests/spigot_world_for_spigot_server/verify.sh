mc-image-helper assert fileExists world/level.dat && \
mc-image-helper assert fileExists world/some_overworld_file && \
mc-image-helper assert fileExists world_nether/DIM-1/some_nether_file && \
mc-image-helper assert fileExists world_the_end/DIM1/some_end_file
