mc-image-helper assert fileExists one.txt mods/two.txt
