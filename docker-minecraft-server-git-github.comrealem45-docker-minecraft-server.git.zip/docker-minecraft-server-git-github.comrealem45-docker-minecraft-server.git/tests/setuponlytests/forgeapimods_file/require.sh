[[ $MINECRAFT_VERSION == LATEST ]] || exit 1
[[ $MODS_FORGEAPI_KEY ]] || exit 1
