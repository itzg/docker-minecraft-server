mc-image-helper assert fileExists custom-plugins/plugin.jar
mc-image-helper assert fileExists custom-mods/mod.jar
mc-image-helper assert fileExists custom-config/test.json
