[[ $VARIANT == java8* ]] || exit 1
