mc-image-helper assert fileExists "/data/FeedTheBeast/forge-installer.jar"
mc-image-helper assert fileExists "/data/FeedTheBeast/forge.jar"
